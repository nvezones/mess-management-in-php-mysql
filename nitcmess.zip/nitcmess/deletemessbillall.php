<?php
	include 'config.php';
	$sql="delete  from tblmessbillfinal;";
	mysqli_query($conn,$sql);
		//$result = mysqli_query($conn,"DELETE * FROM tblmessbillfinal;");
		header("Location:altermessbillfinaldeleteall.php");
		//if(!$result)
		
?>