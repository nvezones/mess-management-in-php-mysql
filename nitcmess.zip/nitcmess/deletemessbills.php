<?php
include 'config.php';

//getting id of the data from url
$staffid = $_GET['staffid'];
echo $staffid;
//deleting the row from table

	$result = mysqli_query($conn, "DELETE FROM tblmessbills WHERE stdID='$staffid'");
	if (!$result)
	{
		echo "not deleted";
	}
header("Location:altertblmessbills.php");
?>