<?php
//including the database connection
include 'config.php';

//getting id of the data from url
$hostelName = $_GET['hostelName'];

//deleting the row from table
$result = mysqli_query($conn, "DELETE FROM tblhostels WHERE hostelName='$hostelName'");

//redirecting to the display page (hostelAlter.php in our case)
header("Location:hostelAlter.php");
?>

