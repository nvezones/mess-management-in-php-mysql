<?php
include 'config.php';
//getting id of the data from url
$staffid = $_GET['staffid'];
echo $staffid;
//deleting the row from table

	$result = mysqli_query($conn, "DELETE FROM tblsetpaymentforstaff WHERE StaffType='$staffid'");
	if (!$result)
	{
		echo "not deleted";
	}
header("Location:altersetpaymentforstaff.php");
?>