<?php
	include 'config.php';
	//getting id of the data from url
	$stdID = $_GET['stdID'];
	//deleting the row from table
	$result = mysqli_query($conn, "DELETE FROM tblstudent WHERE stdID='$stdID'");
	if (!$result)
	{
		echo "not deleted";
	}
	header("Location:stdAlter.php");
?>