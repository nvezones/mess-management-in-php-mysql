<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <!-- Trigger the modal with a button -->
  <!--<button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal"></button>

  <!-- Modal -->
  <div class="modal fade" id="myModalStaffPayment" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content" style="background-color: #222222;">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
  <br><br>
  <div class="panel panel-primary">
    <div class="panel-heading">Staff Payment Form</div>
    <div class="panel-body">
      <form  method="POST"  action="addpaymentstaffload.php" enctype='multipart/form-data'>
  <div class="form-group">
    <label for="roll">Staff Id:</label>
      <?php
    	include('config.php');
    	$sql = "SELECT staffid from tblstaff";
    $result = mysqli_query($conn, $sql);
    $select= '<select name="staffid" class="form-control">';
    if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
    $select.='<option value="'.$row['staffid'].'">'.$row['staffid'].'</option>';
    }
    $select.='</select>';
    echo $select;
  }
  ?>
  </div>
  <div class="form-group">
    <label for="roll">Extra Payment:</label>
    <input type="text" class="form-control" id="email" placeholder="Enter Extra Payment" name="Extra" required>
  </div>
  <div class="form-group">
    <label for="roll">Previous Dues:</label>
    <input type="text" class="form-control" id="email" name="Dues" placeholder="Enter Previous Dues if any" required>
  </div>
  <div class="form-group">
    <label for="roll">Paid Amount:</label>
    <input type="tel" class="form-control" id="email" name="Paid" placeholder="Enter Amount Paid" required>
  </div>
  <button type="submit" id="insert" class="btn btn-default">Submit</button>
</form>
    </div>
    <div class="panel-footer">Thanks you</div>
  </div>
</div>

        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
</div>

</body>
</html>
