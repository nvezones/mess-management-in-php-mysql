<?php
include ('config.php');

if(isset($_POST['update']))
{	
	$staffid     = mysqli_real_escape_string($conn, $_POST['staffid']); 
	$staffname   = mysqli_real_escape_string($conn, $_POST['staffname']);
	$staffMobile = mysqli_real_escape_string($conn, $_POST['staffMobile']);
	$staffAddress = mysqli_real_escape_string($conn, $_POST['staffAddress']);
	$staffType = mysqli_real_escape_string($conn, $_POST['staffType']);
	$staffAadhar   = mysqli_real_escape_string($conn, $_POST['staffAadhar']);
	$sprvsrID    = mysqli_real_escape_string($conn, $_POST['sprvsrID']);
	$file = addslashes(file_get_contents($_FILES['image']['tmp_name']));  
	
		$result = mysqli_query($conn, "UPDATE tblstaff SET staffAddress='$staffAddress', staffMobile='$staffMobile', staffType='$staffType', staffAadhar='$staffAadhar', sprvsrID='$sprvsrID', staffphoto='$file' WHERE staffid='$staffid'");
		if(!$result){
			echo $result;
		}
		header("Location: staffAlter.php");
}
?>
<?php
//getting id from url
$staffid = $_GET['staffid'];

//selecting data associated with this particular id
$result = mysqli_query($conn, "SELECT * FROM tblstaff WHERE staffid='$staffid'");

while($res = mysqli_fetch_array($result))
{
	$staffid     = $res['staffid']; 
	$staffname   = $res['staffname'];
	$staffAddress = $res['staffAddress'];
	$staffMobile = $res['staffMobile'];
	$staffType = $res['staffType'];
	$staffAadhar   = $res['staffAadhar'];
	$sprvsrID    = $res['sprvsrID'];
	$stdPhoto  = $res['staffphoto'];
}
?>
<html>
<head>	
	<title>Edit Data</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
	<!--<script> 

function readURL(input) 
{
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    $('#blah')
                        .attr('src', e.target.result);
                };
                reader.readAsDataURL(input.files[0]);
            }
        }

</script>-->
</head>

<body style="background-color: #222222;">
	<a href="staffAlter.php">Staff Display Page</a>
	<br/><br/>
	
	<form name="form1" method="post" action="editStaff.php" enctype='multipart/form-data'>
		<table border="0" class="table table-dark table-striped">
			<tr> 
				<td>Name</td>
				<td><input type="text" name="staffName" value="<?php echo $staffname;?>" disabled></td>
			</tr>
			<tr> 
				<td>Address</td>
				<td><input type="text" name="staffAddress" value="<?php echo $staffAddress;?>"></td>
			</tr>
			<tr> 
				<td>Mobile</td>
				<td><input type="text" name="staffMobile" value="<?php echo $staffMobile;?>"></td>
			</tr>
			<tr> 
				<td>Staff Type</td>
				<td>
				<?php
				include 'config.php';
				$sql = "SELECT StaffType from tblstafftype";
    			$result = mysqli_query($conn, $sql);
    			$select= '<select name="staffType" class="form-control">'.'<option value="">'.$staffType.'</option>';//."<option value=$row['staffType']>$row['staffType']</option>";
    			if (mysqli_num_rows($result) > 0) 
    			{
      				while($row = mysqli_fetch_assoc($result)) 
      				{
        				$select.='<option value="'.$row['StaffType'].'">'.$row['StaffType'].'</option>';	
        			} 
      				$select.='</select>';
      				echo $select;
    			}
  				?></td>
			</tr>
			<tr> 
				<td>Aadhar</td>
				<td><input type="text" name="staffAadhar" value="<?php echo $staffAadhar;?>"></td>
			</tr>
			<tr> 
				<td>Supervisor</td>
				<td>
				<?php
				include 'config.php';
				$sql = "SELECT staffid from tblstaff";
    			$result = mysqli_query($conn, $sql);
    			$select= '<select name="staffid" class="form-control">'.'<option value="">'.$staffid.'</option>';//."<option value=$row['staffType']>$row['staffType']</option>";
    			if (mysqli_num_rows($result) > 0) 
    			{
      				while($row = mysqli_fetch_assoc($result)) 
      				{
        				$select.='<option value="'.$row['staffid'].'">'.$row['staffid'].'</option>';	
        			} 
      				$select.='</select>';
      				echo $select;
    			}
  				?></td>
			</tr>
			<tr> 
				<td>Photo</td>
				<td> <input type="file" name="image" value="image" />  
				<!--id="blah" onchange="readURL(this);"-->
        		<img src="http://placehold.it/180" alt="your image" height="160" width="128" /></td>
			</tr>
			<tr>
				<td><input type="hidden" name="staffid" value="<?php echo $_GET['staffid'];?>"></td>
				<td><input type="submit" name="update" value="Update"></td>
			</tr>
		</table>
	</form>
</body>
</html>