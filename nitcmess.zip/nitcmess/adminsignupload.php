<?php
   include 'config.php';
    $admin_id=$password="";
     if($_SERVER["REQUEST_METHOD"]=="POST"){
      $admin_id=trim($_POST['admin_id']);
      $password=md5($_POST['pwd']);
      $sql="insert into tbladmin values('$admin_id','$password');";
      if(mysqli_query($conn,$sql))
      {
        echo"<script>alert('New Admin added')</script>";
        header('Location:home.php');
      }
      else
      {
       echo"<script>alert('Some error')</script>"; 
      }
    }
     include('home.php');
      mysqli_close($conn);

?>