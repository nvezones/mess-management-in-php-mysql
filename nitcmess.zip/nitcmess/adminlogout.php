<?php
	session_start();
	session_unset();
	echo "<script>alert('Thanks admin')</script>";
	header('Location:home.php'); 
 ?>