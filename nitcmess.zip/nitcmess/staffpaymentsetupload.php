<?php
   include 'config.php';
    $Stafftype=$amount="";
    if($_SERVER["REQUEST_METHOD"]=="POST"){
      $Stafftype=$_POST['StaffType'];
      $amount=$_POST['amt'];
     // echo $hostel_name;
      $sql="insert into tblsetpaymentforstaff values ('$Stafftype','$amount');";
      if(mysqli_query($conn,$sql))
      {
        echo"<script>alert('New Payment added')</script>";
      }
      else
      {
       echo"<script>alert('Some error while adding')</script>"; 
      }
    }
           mysqli_close($conn);

?>