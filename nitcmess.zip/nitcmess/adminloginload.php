<?php
   include 'config.php';
      $admin_id=$password="";
      if($_SERVER["REQUEST_METHOD"]=="POST"){
        $admin_id=trim($_POST['admin_id']);
        $password=md5($_POST['pwd']);
      $sql="select usrid,password from tbladmin where usrid='$admin_id' and password='$password';";
      if(mysqli_query($conn,$sql))
      {
        //echo"<script>alert(' added')</script>";
        session_start();
        $_SESSION["user"] = $admin_id;
        header('Location:adminmainpage.php');
      }
      else
      {
       echo"<script>alert('Some error')</script>"; 
      // echo $admin_id;
       //echo $password;
      }
    }
      mysqli_close($conn);

?>