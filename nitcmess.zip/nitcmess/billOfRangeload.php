

<html>
<head>  
  <title>Staff Table</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
</head>

<body style="background-color:#222222;">
<a href="adminmainpage.php">Home</a><br/><br/>
<div class="container">
  <table style="width:100%;" border=0 class="table table-dark table-striped">
  <col width="100">
  <col width="100">
  <col width="100">
  <col width="100">
  <col width="100">
  <col width="100">
  <col width="150">
  <col width="100">
  <col width="150">
  <tr bgcolor='#CCCCCC'>
    <th>Student Roll</th>
    <th>Date</th>
    <th>Bill of Day</th>
    <th>Bill Extra</th>
    <th>Bill Total</th>
  </tr>
  <?php 
     include 'config.php';
    $roll=$start=$end="";
    if($_SERVER["REQUEST_METHOD"]=="POST"){
      $roll=trim($_POST['roll']);
      $start=$_POST['startDate'];
      $end=$_POST['endDate'];
       $sql="select * from tblmessbills where  stdID='$roll' and  date BETWEEN '$start' and '$end';";
  //while($res = mysql_fetch_array($result)) { // mysql_fetch_array is deprecated, we need to use mysqli_fetch_array 
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
  while($res = mysqli_fetch_array($result)) {     
    echo "<tr>";
    echo "<td>".$res['stdID']."</td>";
    echo "<td>".$res['date']."</td>";
    echo "<td>".$res['billOfDay']."</td>";
    echo "<td>".$res['billExtra']."</td>";
    echo "<td>".$res['billTotal']."</td>";
  }
}
}
  ?>
  </table>
</div>
</body>
</html>