<?php
	include 'config.php';
   $stdID=$amount=$date="";
    if($_SERVER["REQUEST_METHOD"]=="POST"){
      $stdID=trim($_POST['stdID']);
      $amount=trim($_POST['amt']);
      $date=date("Y-m-d");
      $sql="call setTotalBillForTheDay('$stdID','$date','$amount');";
      if(mysqli_query($conn,$sql))
      {
        echo"<script>alert('New extra added')</script>";
        header('Location:adminmainpage.php');
      }
      else
      {
       echo"<script>alert('Some error while adding')</script>"; 
      }
    }
           mysqli_close($conn);

?>