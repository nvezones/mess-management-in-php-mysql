<?php
   include 'config.php';
    $staff_name="";
    if($_SERVER["REQUEST_METHOD"]=="POST"){
      $staff_name=trim($_POST['staff']);
     // echo $hostel_name;
      $sql="insert into tblstafftype values ('$staff_name');";
      if(mysqli_query($conn,$sql))
      {
        echo"<script>alert('New Staff Catergory added')</script>";
        header('Location:adminmainpage.php');
      }
      else
      {
       echo"<script>alert('Some error while adding')</script>"; 
      }
    }
           mysqli_close($conn);

?>