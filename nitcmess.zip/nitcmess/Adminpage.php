<!DOCTYPE html>
<html>
<head>
	  <title>MESS XYZ</title>
	 <meta charset="utf-8"> 
	 <meta name="viewport" content="width=device-width, initial-scale=1">
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
 	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
 	 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
   <style>
      .page-header{
          //background-color:gray;
          margin-top:0px;
          margin-right:0px;
          margin-left:0px;
          text-align:center;
      }
    </style>
</head>
<body>
	<div class="container">
 	 <!--<p>To make the tabs toggleable, add the data-toggle="pill" attribute to each link. Then add a .tab-pane class with a unique ID for every tab and wrap them inside a div element with class .tab-content.</p>-->
 	 <ul class="nav nav-pills">
   	 <li class="active"><a data-toggle="pill" href="#home">Admin login</a></li>
   	 <li><a data-toggle="pill" href="#menu1">Admin signup</a></li>
  
  <div class="tab-content">
    <div id="home" class="tab-pane fade in active">
       <br><br><?php include 'adminlogin.php';?>
    </div>
    <div id="menu1" class="tab-pane fade">
      &nbsp;<br>
      <br><br><?php include 'adminSignup.php';?>
    </div>
  </div>
</div>


</body>
</html>