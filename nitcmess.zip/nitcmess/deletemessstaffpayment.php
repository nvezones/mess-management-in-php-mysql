<?php
	include 'config.php';
//getting id of the data from url
$staffid = $_GET['staffid'];
//echo $staffid;
//deleting the row from table

	$result = mysqli_query($conn, "DELETE FROM tblmessstaffpayment WHERE staffid='$staffid'");
header("Location:altermessstaffpayment.php");
?>