<!DOCTYPE html>
<html lang="en">
<head>
  <title>Staff Registration</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<style type="text/css">
  img{
  width:128px;
  height:160px;
  right:50%;
}
input[type=file]{
padding:10px;
/*background:#2d2d2d;*/}
</style>

</style>
<script> function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#blah')
                        .attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        } 
</script>
<body>
<div class="container">
  <!-- Trigger the modal with a button -->
  <!--<button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal"></button>

  <!-- Modal -->
  <div class="modal fade" id="myModalStaff" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content" style="background-color:#222222;">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
  <br><br>
  <div class="panel panel-primary">
    <div class="panel-heading">Staff Form</div>
    <div class="panel-body">
    
    <form  method="POST"  action="staffregistrationload.php" enctype='multipart/form-data'>
  <div class="form-group">
    <label for="roll">Staff Id:</label>
    <input type="text" class="form-control" id="email" placeholder="Enter Valid Id" name="staffId" required>
  </div>
  <div class="form-group">
    <label for="roll">Staff Name:</label>
    <input type="text" class="form-control" id="email" placeholder="Enter name" name="name" required>
  </div>
  <div class="form-group">
    <label for="roll">Staff Address:</label>
    <input type="text" class="form-control" id="email" name="Address" placeholder="Enter Address" required>
  </div>
   <div class="form-group">
    <label for="roll">Staff Mobile Number:</label>
    <input type="tel" class="form-control" id="email" name="Mobile" placeholder="Enter Mobile Number" required>
  </div>

  <div class="form-group">
    <label for="roll">Staff Aadhar Number:</label>
    <input type="text" class="form-control" id="email" name="Aadhar" placeholder="Enter Aadhar Number" required>
  </div>
  <div class="form-group">
    <label for="roll">Staff Type:</label>
  <?php
    include 'config.php';
    $sql = "SELECT StaffType from tblstafftype";
    $result = mysqli_query($conn, $sql);
    $select= '<select name="stafftype" class="form-control">';
    if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
    $select.='<option value="'.$row['StaffType'].'">'.$row['StaffType'].'</option>';

    }
    $select.='</select>';
    echo $select;
  }
  ?>
  </div>

  <div class="form-group">
    <label for="roll">Staff Supervisor:</label>
  <?php
    include 'config.php';
    $sql = "SELECT staffid from tblstaff";
    $result = mysqli_query($conn, $sql);
    $select= '<select name="Supervisor" class="form-control">';
    if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
    $select.='<option value="'.$row['staffid'].'">'.$row['staffid'].'</option>';

    }
    $select.='</select>';
    echo $select;
  }
  ?>
  </div>
  
  <div class="form-group">
    <label for="Picture">Upload Picture:</label>
     <input type='file' onchange="readURL(this);" required name="image"/>
        <img id="blah" src="http://placehold.it/180" alt="your image" />
  </div>
  
   <!-- <div class="form-group">
    <label for="Picture">Upload Picture:</label>
     <input type='file' onchange="readURL(this);" required name="image"/>
        <img id="blah" src="http://placehold.it/180" alt="your image" />
  </div>-->
  <button type="submit" id="insert" class="btn btn-default">Submit</button>
</form>


    </div>
    <div class="panel-footer">Thanks for your registration</div>
  </div>
</div>

        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
</div>

</body>
</html>
