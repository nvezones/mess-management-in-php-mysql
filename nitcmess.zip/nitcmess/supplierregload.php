<?php
   include 'config.php';
    $supID=$supName=$supMobile=$supPAN=$supAddress="";
    if($_SERVER["REQUEST_METHOD"]=="POST"){
      $supID=trim($_POST['supID']);
      $supName=$_POST['name'];
      $supMobile=$_POST['mobile'];
      $supPAN=$_POST['pan'];
      $supAddress=$_POST['Address'];
     // echo $hostel_name;
      $sql="insert into tblsupplier values ('$supID','$supName','$supMobile','$supPAN','$supAddress');";
      if(mysqli_query($conn,$sql))
      {
        echo"<script>alert('New Supplier added')</script>";
        header('Location:adminmainpage.php');
      }
      else
      {
       echo"<script>alert('Some error while adding')</script>"; 
      }
    }
           mysqli_close($conn);

?>