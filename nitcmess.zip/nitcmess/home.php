<?php
  include('test.php');
  
  include('testadminlogin.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>MESS MANAGEMENT</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    
</head>
<style>
body, html {
    height: 100%;
    margin: 0;
    width: 100%;
}

.bg {
    /* The image used */
    background-image: url("Webp.net-gifmaker (3).gif");

    /* Full height */
    height: 100%; 
    width: 100%;
    /* Center and scale the image nicely */
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
}
.body
{
    background-color: gray;
}
</style>
<body>
  <div class="bg">
  <div class="container">
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Mess Management</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="#">Home</a></li>
      <!--<li><a href="#" data-toggle="modal" data-target="#myModal">Student Registration</a></li>-->
      
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="#" data-toggle="modal" data-target="#myModaladminlogin"><span class="glyphicon glyphicon-user"></span>Admin Login</a></li>
    </ul>
  </div>
</nav>
</div>
</div>
</body>
</html>