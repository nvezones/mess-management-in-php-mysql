<?php
//including the database connection file
include('config.php');
$sql="call getAllBill()";
mysqli_query($conn,$sql);
$result = mysqli_query($conn, "SELECT * FROM tblmessbillfinal ORDER BY stdID"); // using mysqli_query instead
?>

<html>
<head>	
	<title>Student  Final Bill</title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
</head>

<body style="background-color: black;">
<a href="adminmainpage.php">Home</a>
<a href="deletemessbillall.php" style="float: right;">Delete All</a><br><br>
<div class="container">
	<table style="width:100%;" border=0 class="table table-dark table-striped">
	<col width="100">
	<col width="100">
	<col width="100">
	<col width="100">
	<col width="100">
	<col width="100">
	<col width="150">
	<col width="100">
	<col width="150">
	<tr bgcolor='#CCCCCC'>
		<th>Student Roll</th>
		<th>Regular Bill</th>
		<th>Extra Bill</th>
		<th>Total Bill</th>
		<th>Month</th>
	</tr>
	<?php 
	//while($res = mysql_fetch_array($result)) { // mysql_fetch_array is deprecated, we need to use mysqli_fetch_array 
	while($res = mysqli_fetch_array($result)) { 		
		echo "<tr>";
		echo "<td>".$res['stdID']."</td>";
		echo "<td>".$res['Regular_bill']."</td>";
		echo "<td>".$res['Extra_bill']."</td>";
		echo "<td>".$res['Total_bill']."</td>";
		echo "<td>".$res['month']."</td>";
		echo "<td><a href=\"deletemessbillfinal.php?staffid=$res[stdID]&month=$res[month]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td>";		
	}
	?>
	</table>
</div>
</body>
</html>