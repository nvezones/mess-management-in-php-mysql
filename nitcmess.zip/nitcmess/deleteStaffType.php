<?php
include 'config.php';
//getting id of the data from url
$staffType = $_GET['staffType'];
echo $staffType;
//deleting the row from table

  $result = mysqli_query($conn, "DELETE FROM tblstafftype WHERE staffType='$staffType'");
  if (!$result)
  {
    echo "not deleted";
  }
header("Location:alterStaffType.php");
?>