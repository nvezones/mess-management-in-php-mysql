<?php
	include 'config.php';
//getting id of the data from url
$staffid = $_GET['staffid'];
$month = $_GET['month'];


	$result = mysqli_query($conn, "DELETE FROM tblmessbillfinal WHERE 
stdID='$staffid' and month='$month';");
header("Location:altermessbillfinal.php");
?>