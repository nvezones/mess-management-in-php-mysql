<?php
   include 'config.php';
    $hostel_name="";
    if($_SERVER["REQUEST_METHOD"]=="POST"){
      $hostel_name=trim($_POST['hostel']);
      echo $hostel_name;
      $sql="insert into tblhostels values ('$hostel_name');";
      if(mysqli_query($conn,$sql))
      {
        echo"<script>alert('New Hostel added')</script>";
        header('Location:adminmainpage.php');
      }
      else
      {
       echo"<script>alert('Some error while adding')</script>"; 
      }
    }
           mysqli_close($conn);

?>