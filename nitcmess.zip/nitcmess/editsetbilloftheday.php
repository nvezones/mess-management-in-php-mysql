<?php
   include 'config.php';

if($_SERVER["REQUEST_METHOD"]=="POST")
{	

	$billOfDay      = trim($_POST['billOfDay']);
	
	$result = mysqli_query($conn,"call 	setBillOfTheDay('$billOfDay');");
	if($result){
		echo "result";
		header('Location:altersetbilloftheday.php');
	}
	else
	{
		echo "no result";
	}

		//redirectig to the display page. In our case, it is index.php
	//header("Location: staffAlter.php");
}
?>
<?php
//getting id from url
$staffid = $_GET['staffid'];
//echo $staffid;
//echo $staffid;
//selecting data associated with this particular id
$result = mysqli_query($conn, "SELECT * FROM tblsetpaymentforstaff WHERE StaffType='$staffid'");

while($res = mysqli_fetch_array($result))
{
	$StaffType      = $res['StaffType']; 
	$Salary   = $res['Salary'];
}

?>
<html>
<head>	
	<title>Edit Data</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
</head>

<body>
	<a href="altersetbilloftheday.php">Home</a>
	<br/><br/>
	<form name="form1" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
		<table border="0" class="table table-dark table-striped">
			<tr> 
				<td>Staff Type</td>
				<td><input type="text" name="billOfDay"    value="<?php echo $staffid;?>"></td>
			</tr>
			<tr>
				<td><input type="hidden" name="staffid" value="<?php echo $_GET['staffid'];?>"></td>
				<td><input type="submit" name="update" value="Update"></td>
			</tr>
		</table>
	</form>
</body>
</html>