<?php
   include 'config.php';
    $hostel_name="";
    if($_SERVER["REQUEST_METHOD"]=="POST"){
      $hostel_name=trim($_POST['hostel']);
      echo $hostel_name;
      $sql="delete from tblhostels where hostelName='$hostel_name';";
      if(mysqli_query($conn,$sql))
      {
        echo"<script>alert('Hostel Deleted')</script>";
      }
      else
      {
       echo"<script>alert('Some error while Deleting')</script>"; 
      }
    }
           mysqli_close($conn);

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Add & remove hostel</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
    <br>&nbsp;&nbsp;&nbsp;&nbsp;
  <input type="button" value="Go back!" class="btn btn-link" onclick="history.back()"><br><br>
  <div class="container">
    <div class="row">
      <div class="col-sm-3">
      </div>
      <div class="col-sm-6 ">
      <div class="panel panel-primary">
      <div class="panel-heading">Remove hostel</div>
      <div class="panel-body">
        <form method="POST"  action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" enctype='multipart/form-data'>
         <div class="form-group">
        <label for="admin_id">Enter Hostel Name:</label>
        <!--<input type="text" class="form-control" id="email" placeholder="Enter Hostel Name" name="hostel">-->
        <?php
        include 'config.php';
        $sql = "SELECT hostelName from tblhostels";
        $result = mysqli_query($conn, $sql);
        $select= '<select name="hostel" class="form-control">'.'<option value="">Choose Hostel Name</option>';
        if (mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_assoc($result)) {
          $select.='<option value="'.$row['hostelName'].'">'.$row['hostelName'].'</option>';
        }
        $select.='</select>';
        echo $select;
        }
        ?>
        </div>
        <button type="submit" class="btn btn-default">Submit</button>
      </form>
    </div>
    </div>
  </div>
  </div>
</div>
</body>
</html>