<?php
  include 'config.php';
  $hostelName="";
  $hostelNew="";
  if($_SERVER["REQUEST_METHOD"]=="POST")
  { 
    $hostelName = trim($_POST['hostelName1']);
    $hostelNew = trim($_POST['hostelNameNew']);
    
    echo $hostelName;
    $result = mysqli_query($conn,"UPDATE tblhostels SET hostelName='$hostelNew' WHERE hostelName='$hostelName';");
    if($result){
      echo "<script>window.alert($hostelName)</script>";
    echo "result";
    header('Location:hostelAlter.php');
  }
  else
  {
    echo "no result";
  }
}
?>
<?php
//getting id from url
$hostelNameOld = $_GET['hostelName'];

//selecting data associated with this particular id
// $result = mysqli_query($conn, "SELECT * FROM tblhostels WHERE hostelName='$hostelName'");

// while($res = mysqli_fetch_array($result))
// { 
//   $hostelName = $res['hostelName'];
// }

?>
<html>
<head>  
  <title>Edit Data</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
</head>

<body style="background-color: #222222; color: white;">
  <a href="adminmainpage.php">Home</a>
  <br/><br/>
  <form name="form1" method="post" action="hostelmodify.php">
    <table border="0" class="table table-dark table-striped">
      <tr> 
        <td>Hostel Name</td>
        <td><input type="text" name="hostelName1"  value="<?php echo $hostelNameOld;?>"></td>
      </tr>
       <tr> 
        <td>New Hostel Name</td>
        <td><input type="text" name="hostelNameNew"  value="<?php echo $hostelNameOld;?>"></td>
      </tr>
      <tr>
        <td><input type="hidden" name="hostelName" value="<?php echo $_GET['hostelName'];?>"></td>
        <td><input type="submit" name="update" value="Update"></td>
      </tr>
    </table>
  </form>
</body>
</html>s