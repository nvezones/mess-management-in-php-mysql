<?php
include ('config.php');

if(isset($_POST['update']))
{	
	$stdID     = mysqli_real_escape_string($conn, $_POST['stdID']); 
	$stdName   = mysqli_real_escape_string($conn, $_POST['stdName']);
	$stdMailID = mysqli_real_escape_string($conn, $_POST['stdMailID']);
	$stdMobile = mysqli_real_escape_string($conn, $_POST['stdMobile']);
	$stdHostel = mysqli_real_escape_string($conn, $_POST['stdHostel']);
	$stdRoom   = mysqli_real_escape_string($conn, $_POST['stdRoom']);
	$Active    = mysqli_real_escape_string($conn, $_POST['Active']);
	$file = addslashes(file_get_contents($_FILES['image']['tmp_name']));  
	
		$result = mysqli_query($conn, "UPDATE tblstudent SET stdMobile='$stdMobile', stdMailID='$stdMailID', stdHostel='$stdHostel', stdRoom='$stdRoom', Active='$Active', stdPhoto='$file' WHERE stdID='$stdID'");
		if(!$result){
			echo $result;
		}
		
		header("Location: stdAlter.php");
}
?>
<?php
//getting id from url
$stdID = $_GET['stdID'];

//selecting data associated with this particular id
$result = mysqli_query($conn, "SELECT * FROM tblstudent WHERE stdID='$stdID'");

while($res = mysqli_fetch_array($result))
{
	$stdID     = $res['stdID']; 
	$stdName   = $res['stdName'];
	$stdMobile = $res['stdMobile'];
	$stdMailID = $res['stdMailID'];
	$stdHostel = $res['stdHostel'];
	$stdRoom   = $res['stdRoom'];
	$Active    = $res['Active'];
	$stdPhoto  = $res['stdPhoto'];
}
?>
<html>
<head>	
	<title>Edit Data</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
	<script> 

function readURL(input) 
{
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    $('#blah')
                        .attr('src', e.target.result);
                };
                reader.readAsDataURL(input.files[0]);
            }
        }

</script>
</head>

<body>
	<a href="stdAlter.php">Student Edit Form</a>
	<br/><br/>
	
	<form name="form1" method="post" action="editStudent.php" enctype='multipart/form-data'>
		<table border="0" class="table table-dark table-striped">
			<tr> 
				<td>Name</td>
				<td><input type="text" name="stdMobile" value="<?php echo $stdName;?>" disabled></td>
			</tr>
			<tr> 
				<td>Mobile</td>
				<td><input type="text" name="stdMobile" value="<?php echo $stdMobile;?>"></td>
			</tr>
			<tr> 
				<td>Mail ID</td>
				<td><input type="text" name="stdMailID" value="<?php echo $stdMailID;?>"></td>
			</tr>
			<tr> 
				<td>Hostel</td>
				<td><input type="text" name="stdHostel" value="<?php echo $stdHostel;?>"></td>
			</tr>
			<tr> 
				<td>Room No</td>
				<td><input type="text" name="stdRoom" value="<?php echo $stdRoom;?>"></td>
			</tr>
			<tr> 
				<td>Status</td>
				<td><input type="text" name="Active" value="<?php echo $Active;?>"></td>
			</tr>
			<tr> 
				<td>Photo</td>
				<td> <input type="file" name="image" value="image" />  
				<!--<img id="blah" onchange="readURL(this);" src="http://placehold.it/180" alt="your image" height="160" width="128" />-->
        		<img src="http://placehold.it/180" alt="your image" height="160" width="128" /></td>
			</tr>
			<tr>
				<td><input type="hidden" name="stdID" value="<?php echo $_GET['stdID'];?>"></td>
				<td><input type="submit" name="update" value="Update"></td>
			</tr>
		</table>
	</form>
</body>
</html>