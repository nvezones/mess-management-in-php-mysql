<?php
	include('config.php');
	$staff=$extra=$dues=$paid="";
	if($_SERVER["REQUEST_METHOD"]=="POST"){
		$staff=$_POST['staffid'];
		$extra=trim($_POST['Extra']);
		$dues=trim($_POST['Dues']);
		$paid=trim($_POST['Paid']);
	$sql1="call addStaffSalaryToMSP();";
	mysqli_query($conn,$sql1);
    $sql="call addPaymentStaff('$extra','$dues','$paid','$staff');";
    if(mysqli_query($conn,$sql))
    {
        //echo"<script>alert(' added')</script>";
        header('Location:altermessstaffpayment.php');
    }
   }
      mysqli_close($conn);

?>