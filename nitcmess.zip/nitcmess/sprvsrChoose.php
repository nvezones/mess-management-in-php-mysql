<?php
    include 'config.php';
    $sql = "SELECT staffid from tblstaff";
    $result = mysqli_query($conn, $sql);
    $select= '<select name="sprvsrID" class="form-control">'.'<option value="">Choose Supervisor ID</option>';
    if (mysqli_num_rows($result) > 0) 
    {
      while($row = mysqli_fetch_assoc($result)) 
      {
        $select.='<option value="'.$row['staffid'].'">'.$row['staffid'].'</option>';
      } 
      $select.='</select>';
      echo $select;
     // $sprvsrIDref = $_POST['sprvsrID'];
    }
  ?>