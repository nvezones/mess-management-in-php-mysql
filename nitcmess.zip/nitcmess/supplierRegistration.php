<?php
    include 'config.php';
    $supID=$name=$mobile=$PAN=$address="";
    if($_SERVER["REQUEST_METHOD"]=="POST"){
        $supID=$_POST['id'];
        $name=$_POST['name'];
        $PAN=$_POST['PAN'];
        $mobile=$_POST['mobile'];
        $address=$_POST['address'];
        //$hostelroom=$_POST['hostelroom'];
        //$active = 1;
        //$file=addslashes(file_get_contents($_FILES["image"]["temp_name"]));
        //$image = addslashes(file_get_contents($_FILES['image']['tmp_name'])); //SQL Injection defence!
        //$image_name = addslashes($_FILES['image']['name']);
        ///echo $image_name;
        //if(isset($_FILES['image'])){
         $sql="insert into tblsupplier values('$supID','$name','$mobile','$PAN','$address');";
        //}
         if(mysqli_query($conn, $sql))
         {
                echo "<script>alert('data is inserted')</script>";
         }
         else
         {
                echo "<script>alert('Error in uploading registration')</script>"; 
         }
    
        }
        mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Supplier Registration</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<!--<script> function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#blah')
                        .attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        } 
</script>-->
<body>
  <input type="button" value="Go back!" class="btn btn-link" onclick="history.back()"><br><br>
<div class="container">
  <br><br>
  <div class="panel panel-primary">
    <div class="panel-heading">Supplier Form</div>
    <div class="panel-body">
      <form  method="POST"  action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" enctype='multipart/form-data'>
  <div class="form-group">
    <label for="roll">Supplier ID:</label>
    <input type="text" class="form-control" id="email" placeholder="Enter Supplier ID" name="id" required>
  </div>
  <div class="form-group">
    <label for="roll">Supplier Name:</label>
    <input type="text" class="form-control" id="email" placeholder="Enter name" name="name" required>
  </div>
   <div class="form-group">
    <label for="roll">Supplier Mobile:</label>
    <input type="tel" class="form-control" id="email" placeholder="Enter Mobile Number" name="mobile" required>
  </div>
   <div class="form-group">
    <label for="roll">PAN Number:</label>
    <input type="text" class="form-control" id="email" placeholder="Enter PAN Number" name="PAN" required>
  </div>
  <div class="form-group">
    <label for="roll">Supplier Address:</label>
    <input type="text" class="form-control" id="email" placeholder="Enter Address" name="address" required>
  </div>
  <button type="submit" id="insert" class="btn btn-default">Submit</button>
</form>
    </div>
    <div class="panel-footer">Thanks for your registration</div>
  </div>
</div>
</body>
</html>