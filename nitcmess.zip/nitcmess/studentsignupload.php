<?php
    include 'config.php';
    $roll=$name=$email=$mobile=$hostelName=$hotelroom=$image=$image_name="";
    if($_SERVER["REQUEST_METHOD"]=="POST"){
        $roll=$_POST['roll'];
        $name=$_POST['name'];
        $email=$_POST['email'];
        $mobile=$_POST['mobile'];
        $hostelName=$_POST['hostelname'];
        $hostelroom=$_POST['hostelroom'];
        $active = 1;
        //$file=addslashes(file_get_contents($_FILES["image"]["temp_name"]));
        $image = addslashes(file_get_contents($_FILES['image']['tmp_name'])); //SQL Injection defence!
        $image_name = addslashes($_FILES['image']['name']);
        ///echo $image_name;
        //if(isset($_FILES['image'])){
         $sql="insert into tblstudent values('$roll','$name','$mobile','$email','$hostelName','$hostelroom','$image','$active');";
        //}
         if(mysqli_query($conn, $sql) and $_FILES["image"]["size"]<=655360)
         {
                echo "<script>alert('data is inserted')</script>";
                header('Location:adminmainpage.php');

         }
         else
         {
                echo "<script>alert('Error in uploading registration')</script>"; 
         }
    
        }
      
        mysqli_close($conn);
?>
