<?php
   include 'config.php';

if($_SERVER["REQUEST_METHOD"]=="POST")
{	

	$supID      = trim($_POST['supID']);
	$supName    = trim($_POST['supName']);
	$supMobile  = trim($_POST['supMobile']);
	$supPAN     = trim($_POST['supPAN']);
	$supAddress = trim($_POST['supAddress']);

	$result = mysqli_query($conn,"UPDATE tblsupplier SET supName='$supName', supMobile='$supMobile', supPAN='$supPAN', supAddress='$supAddress' WHERE supID='$supID';");
	if($result){
		echo "result";
		header('Location:supplierAlter.php');
	}
	else
	{
		echo "no result";
	}

		//redirectig to the display page. In our case, it is index.php
	//header("Location: staffAlter.php");
}
?>
<?php
//getting id from url
$supID = $_GET['supID'];
//echo $staffid;
//echo $staffid;
//selecting data associated with this particular id
$result = mysqli_query($conn, "SELECT * FROM tblsupplier WHERE supID='$supID'");

while($res = mysqli_fetch_array($result))
{
	$supID      = $res['supID']; 
	$supName    = $res['supName'];
	$supMobile  = $res['supMobile'];
	$supPAN     = $res['supPAN'];
	$supAddress = $res['supAddress'];
}

?>
<html>
<head>	
	<title>Edit Data</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
</head>

<body>
	<a href="adminmainpage.php">Home</a>
	<br/><br/>
	<form name="form1" method="post" action="editSupplier.php">
		<table border="0" class="table table-dark table-striped">
			<tr> 
				<td>Supplier ID</td>
				<td><input type="text" name="supID"    value="<?php echo $supID;?>" disabled></td>
			</tr>
			<tr> 
				<td>Name</td>
				<td><input type="text" name="supName"  value="<?php echo $supName;?>"></td>
			</tr>
			<tr> 
				<td>Mobile</td>
				<td><input type="text" name="supMobile" value="<?php echo $supMobile;?>"></td>
			</tr>
			<tr> 
				<td>PAN</td>
				<td><input type="text" name="supPAN" value="<?php echo $supPAN;?>"></td>
			</tr>
			<tr> 
				<td>Address</td>
				<td><input type="text" name="supAddress" value="<?php echo $supAddress;?>"></td>
			</tr>
			<tr>
				<td><input type="hidden" name="supID" value="<?php echo $_GET['supID'];?>"></td>
				<td><input type="submit" name="update" value="Update"></td>
			</tr>
		</table>
	</form>
</body>
</html>