<?php
//including the database connection file
$conn = mysqli_connect("localhost","root","","nitcmess");
    if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }
$result = mysqli_query($conn, "SELECT * FROM tblhostels ORDER BY hostelName"); // using mysqli_query instead
?>

<html>
<head>	
	<title>Hostel Table</title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
</head>

<body  style="background-color: #222222;">
<a href="adminmainpage.php">Home</a><br/><br/>
<div class="container">
	<table style="width:100%;" border=0 class="table table-dark table-striped">
	<col width="150">
	<tr bgcolor='#CCCCCC'>
		<th>Serial No</th>
		<th>Hostel Name</th>
		<th>Update</th>
	</tr>
	<?php 
	//while($res = mysql_fetch_array($result)) { // mysql_fetch_array is deprecated, we need to use mysqli_fetch_array 
	$i=0;
	while($res = mysqli_fetch_array($result)) {
		$i += 1; 		
		echo "<tr>";
		echo "<td>".$i."</td>";
		echo "<td>".$res['hostelName']."</td>";
		echo "<td><a href=\"hostelmodify.php?hostelName=$res[hostelName]\">Edit</a> | <a href=\"deleteHostelCrud.php?hostelName=$res[hostelName]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td>";		
	}
	?>
	</table>
</div>
</body>
</html>