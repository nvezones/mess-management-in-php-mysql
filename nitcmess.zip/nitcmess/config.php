<?php
$conn=mysqli_connect('localhost','root','','nitcmess');
if(!$conn){
  die("connection failed to connect".mysqli_connect_error());
}
?>