<?php
  session_start();
  include('test.php');
  include('teststaffregistration.php');
  include('testaddhostel.php');
  include('testaddstafftype.php');
  include('teststudentextrabill.php');
  include('testsetstaffpayment.php');
  include('testaddsupplier.php');
  include('BillOfRange.php');
  include('testaddpaymentstaff.php');
  include ('testadminsignup.php');
?>
<!DOCTYPE html>
<html>
<head>
    <title>ADMIN CONTROL PANEL</title>
   <meta charset="utf-8"> 
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
   <link rel="stylesheet" href="style.css">
</head>
<body background="Images/blackwood.jpg">
  <h1 style="font-size: 5em;" class="neon" data-text="Welcome Admin"><?php echo "Welcome ".$_SESSION['user'];?></h1>
	<div class="container">
    <div class="page-header">
 	 <h2>Admin Panel</h2>
  </div>
 	 <!--<p>To make the tabs toggleable, add the data-toggle="pill" attribute to each link. Then add a .tab-pane class with a unique ID for every tab and wrap them inside a div element with class .tab-content.</p>-->
 	 <ul class="nav nav-pills">
    <!--<li class="active"><a data-toggle="pill" href="adminlogin.php">Sign In</a></li>
    <li><a data-toggle="pill" href="#home">Staff Registration</a></li>-->
      <nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      
    </div>
    <ul class="nav navbar-nav">
      <li><a href="#" class="active">Home</a></li>
      <li><a href="#" data-toggle="modal" data-target="#myModalStaff">Staff Registration</a></li>
      <li><a href="#" data-toggle="modal" data-target="#myModalStaffType">Staff Type Registration</a></li>
      <li><a href="#" data-toggle="modal" data-target="#myModal">Student Registration</a></li>
      <li><a href="#" data-toggle="modal" data-target="#myModalHostel">Hostel Registration</a></li>
      <li><a href="#" data-toggle="modal" data-target="#myModalstudentextra">Student extras</a></li>
      <li><a href="#" data-toggle="modal" data-target="#myModalstaffpayment">Staff Payment Setup</a></li>
      <li><a href="#" data-toggle="modal" data-target="#myModalBillOfRange">Bill of Range</a></li>
      <li><a href="#" data-toggle="modal" data-target="#myModalStaffPayment">Staff Payments</a></li>
      <li><a href="#" data-toggle="modal" data-target="#myModalSupplier">Supplier Registration</a></li>
      <li><a href="#" data-toggle="modal" data-target="#myModaladminsignup">Add Admin</a></li>
    </ul>


    <ul class="nav navbar-nav navbar-right">
      <li><a href="adminlogout.php"><span class="glyphicon glyphicon-user"></span>Admin Logout</a></li>
    </ul>
  </div>
</nav>
  
<div class="btn-group-vertical">
  <a href="staffAlter.php"><button type="button" class="btn" style="background-color: #222222; color:gray; ">Show Staffs</button></a><br><br>
  <a href="alterStaffType.php"><button type="button" class="btn" style="background-color: #222222; color:gray; ">Show StaffType</button><br></a><br>
  <a href="stdAlter.php"><button type="button" class="btn" style="background-color: #222222; color:gray; ">Show Students</button></a><br><br>
   <a href="altermessbillfinal.php"><button type="button" class="btn" style="background-color: #222222; color:gray; ">Show Final Bills</button></a><br><br>
   <a href="altersetbilloftheday.php"><button type="button" class="btn" style="background-color: #222222; color:gray; ">Show Bill per Day</button></a><br><br>
    <a href="showadmin.php"><button type="button" class="btn" style="background-color: #222222; color:gray;">Show Admin</button></a><br><br>
  
</div>
<div class="btn-group-vertical" style="float: right;">
  
     <a href="altertblmessbills.php"><button type="button" class="btn" style="background-color: #222222; color:gray; ">Show Student Bill per Day</button></a><br><br>
   <a href="altermessstaffpayment.php"><button type="button" class="btn" style="background-color: #222222; color:gray; ">Show  Staff Payment</button></a><br><br>
   <a href="altersetpaymentforstaff.php"><button type="button" class="btn" style="background-color: #222222; color:gray; ">Show StaffType Salary</button></a><br><br>
   <a href="hostelAlter.php"><button type="button" class="btn" style="background-color: #222222; color:gray; ">Show Hostel</button></a><br><br>
    <a href="supplierAlter.php"><button type="button" class="btn" style="background-color: #222222; color:gray; ">Show Supplier</button></a><br><br>
  </div>
</div>
</body>
</html>