<?php
    include 'config.php';
    $staffid=$name=$mobile=$image=$image_name=$aadhar=$staffType=$sprvsrID="";
    if($_SERVER["REQUEST_METHOD"]=="POST"){
        @$staffid=$_POST['staffId'];
        //echo $staffid.",".$staffType;
        $name=$_POST['name'];
        $address=$_POST['Address'];
        $mobile=$_POST['Mobile'];
        $aadhar=$_POST['Aadhar'];
        @$staffType=$_POST['stafftype'];
        $sprvsrID=$_POST['Supervisor'];
        #echo $staffid.",".$staffType;
        //$file=addslashes(file_get_contents($_FILES["image"]["temp_name"]));
        $image = addslashes(file_get_contents($_FILES['image']['tmp_name'])); //SQL Injection defence!
        $image_name = addslashes($_FILES['image']['name']);

        
        //include 'sprvsrChoose.php';
        //$sprvsrID = $sprvsrIDref;
        
        ///echo $image_name;
        //if(isset($_FILES['image'])){
         $sql="insert into tblstaff values('$staffid','$name','$address','$mobile','$staffType','$aadhar','$sprvsrID','$image');";
        // echo $staffid.$name.$address.$mobile.$staffType.$aadhar.$sprvsrID;
        //}
         #echo "File Size = ".filesize($_FILES["image"]["size"])."Bytes";
         if(mysqli_query($conn, $sql) and $_FILES["image"]["size"]<=655360)
         {
                echo "<script>alert('data is inserted')</script>";
                header('Location:adminmainpage.php');
         }
         else
         {
                echo "<script>alert('Error in uploading registration')</script>"; 
         }
        }
        mysqli_close($conn);
?>
