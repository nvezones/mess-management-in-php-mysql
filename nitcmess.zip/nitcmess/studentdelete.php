<?php
   include 'config.php';
    $roll="";
    if($_SERVER["REQUEST_METHOD"]=="POST"){
      $roll=trim($_POST['roll']);
     // echo $hostel_name;
      $sql="update tblstudent set status=0 where stdID='$roll';";
      if(mysqli_query($conn,$sql))
      {
        echo"<script>alert('Student Deleted')</script>";
      }
      else
      {
       echo"<script>alert('Some error while Deleting')</script>"; 
      }
    }
           mysqli_close($conn);

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Student Registration</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
    <br>&nbsp;&nbsp;&nbsp;&nbsp;
  <input type="button" value="Go back!" class="btn btn-link" onclick="history.back()"><br><br>
  <div class="container">
    <div class="row">
      <div class="col-sm-3">
      </div>
      <div class="col-sm-6 ">
      <div class="panel panel-primary">
      <div class="panel-heading">Remove Student</div>
      <div class="panel-body">
        <form method="POST"  action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" enctype='multipart/form-data'>
         <div class="form-group">
        <label for="admin_id">Enter Student Roll:</label>
        <!--<input type="text" class="form-control" id="email" placeholder="Enter Hostel Name" name="hostel">-->
        <?php
        include 'config.php';
        $sql = "SELECT stdID from tblstudent";
        $result = mysqli_query($conn, $sql);
        $select= '<select name="roll" class="form-control">'.'<option value="">Choose Student Roll</option>';
        if (mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_assoc($result)) {
          $select.='<option value="'.$row['stdID'].'">'.$row['stdID'].'</option>';
        }
        $select.='</select>';
        echo $select;
        }
        ?>
        </div>
        <button type="submit" class="btn btn-default">Submit</button>
      </form>
    </div>
    </div>
  </div>
  </div>
</div>
</body>
</html>