<?php
include('config.php');

$result = mysqli_query($conn, "SELECT * FROM tblstaff ORDER BY staffid"); // using mysqli_query instead
?>

<html>
<head>	
	<title>Staff Table</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
</head>

<!--<body background="bgBlue.jpg" style="background-size:cover; background-repeat:no-repeat;">-->
<body style="background-color:#222222;">
<a href="adminmainpage.php">Home</a><br/><br/>
<div class="container">
	<table style="width:100%;" border=0 class="table table-dark table-striped">
	<col width="100">
	<col width="100">
	<col width="100">
	<col width="100">
	<col width="100">
	<col width="100">
	<col width="150">
	<col width="100">
	<col width="150">
	<tr bgcolor='#CCCCCC'>
		<th>Staff ID</th>
		<th>Name</th>
		<th>Address</th>
		<th>Mobile</th>
		<th>Staff Type</th>
		<th>Aadhar</th>
		<th>Supervisor</th>
		<th>Photo</th>
		<th>Update</th>
	</tr>
	<?php 
	//while($res = mysql_fetch_array($result)) { // mysql_fetch_array is deprecated, we need to use mysqli_fetch_array 
	while($res = mysqli_fetch_array($result)) { 		
		echo "<tr>";
		echo "<td>".$res['staffid']."</td>";
		echo "<td>".$res['staffname']."</td>";
		echo "<td>".$res['staffAddress']."</td>";
		echo "<td>".$res['staffMobile']."</td>";
		echo "<td>".$res['staffType']."</td>";
		echo "<td>".$res['staffAadhar']."</td>";
		/*if($res['Active']==1)
			echo "<td>"."Active"."</td>";
		else
			echo "<td>"."Inactive"."</td>";*/
		echo "<td>".$res['sprvsrID']."</td>";
		echo '<td><img src="data:image/jpeg;base64,'.base64_encode($res['staffphoto'] ).'" height="160" width="128" class="img-thumnail" /></td>';

			
		echo "<td><a href=\"editStaff.php?staffid=$res[staffid]\">Edit</a> | <a href=\"deleteStaff.php?staffid=$res[staffid]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td>";		
	}
	?>
	</table>
</div>
</body>
</html>